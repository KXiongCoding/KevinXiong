# SET Hacks 2020 Submission
This is Alex's submission for the 2020 SET Hackathon.
It is an aquaponics simulator that accurately models the conditions and behaviours of plants and fish.
